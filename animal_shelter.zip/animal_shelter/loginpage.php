<html>
<head>
    
	  <style>
<?php 
include 'adminmain.css'; 
    ?>
</style>
</head>
    <ul>

   <li>  
	<form method="post" action="login.php">	
	<button type="submit" class="cancelbtn" name="logout" style="float:right;font-size:22px"><b>Log Out</b></button>
	</form>
  </li>
	
</ul>


<div class="container" style="width:100%">
	<div class="container" >
	<form method="post">
      <center><button type="button" onclick="window.location.href='appointment_tbl.php'" style="background-color:#2B4F76">Book Appointment</button>
	  <button type="button" onclick="window.location.href='cancelapp.php'" style="float:center;background-color:#2B4F76">Show appointment</button>
	  <button type="button" onclick="window.location.href='request.php'" style="float:center;background-color:#2B4F76">Request For a Pet</button>
	  <button type="button" onclick="window.location.href='display.php'" style="float:center;background-color:#2B4F76">Browse Pet</button>
        </center>
	</form>
    </div>
</div>

</body>
</html>