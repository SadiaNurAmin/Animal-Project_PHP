<style>
<?php 
include 'adminmain.css'; 
    ?>
</style>
<li>  
	<form method="post" action="homepage.php">	
	<button type="submit" class="cancelbtn" name="logout" style="float:right;font-size:22px"><b>Log Out</b></button>
	</form>
  </li>
<br>
<br>
<br>
<br>

<center><h1>Insert Animal Details</h1><hr>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
 
  Name: <input type="text" name="animal_name" required>
  <br>
  Gender:
  <input type="radio" name="animal_gender" value="female">Female
  <input type="radio" name="animal_gender" value="male">Male
  <br>
    <br>
  Breed: <input type="text" name="animal_breed" required>
  <br>
  Animal Type: <input type ="text" name="animal_type" required>
  <br>
  Animal ID:<input type="number" name="animal_id" required>
  <br>
  Animal Age: <input type="number" name="animal_age"  required>
  <br>
    <br>
  Details About Animal:  <textarea name="animal_detail" cols="35" rows="10"></textarea> 
  <br>
     <tr>
             <td align="right"><b>Animal Picture</b></td>
            <td><input type="file" name="animal_image" /></td>
            
            
            </tr>
  
 
  
  <button type="submit" name="insert_data">ADD</button>
</form>
    
</font></b>
</center>
<?php
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con,'animal__shelter');


if(isset($_POST['insert_data'])){
   
    $animal_name = $_POST['animal_name'];
    $animal_gender = $_POST['animal_gender'];
    $animal_breed = $_POST['animal_breed'];
    $animal_type = $_POST['animal_type' ];
    $animal_id = $_POST['animal_id'];
    $animal_age = $_POST['animal_age'];
    $animal_detail = $_POST['animal_detail'];
    $animal_image = $_FILES['animal_image']['name'];
    $temp_animal_image = $_FILES['animal_image']['name'];
  
 
    
         $s = "select * from dogs where id= '$animal_id'";
$result = mysqli_query($con, $s);
$num = mysqli_num_rows($result);

if($num == 1){
echo "Animal already registered";
}
        else{

        
        move_uploaded_file($temp_animal_image,"doggy_pic/$animal_image");
        
        $insert_data="insert into dogs (animal_type,name,gender,breed,id,age,detail,image) values ('$animal_type','$animal_name','$animal_gender','$animal_breed','$animal_id','$animal_age','$animal_detail','$animal_image')";
 
           
        
        mysqli_query($con,$insert_data);
            echo "<script>alert('Data inserted successfully')</script>";
        }

  
    
    }


?>

</body>
</html>