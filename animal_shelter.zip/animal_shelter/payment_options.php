<style>
<?php 
include 'payCSS.css'; 
    ?>
</style>
<body style="background-image:url(doggy/wow1.jpg)">


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Paypal Integration Test</title>
</head>
<body>


<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick" />
<input type="hidden" name="hosted_button_id" value="ETVSDXVPSZ4GA" />
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    
<input type="image" src="https://www.paypalobjects.com/en_AU/i/btn/btn_donateCC_LG.gif" border="40" name="submit" title="PayPal - The safer, easier way to pay online!" alt="Donate with PayPal button" />
<img alt="" float= "center" border="0" src="https://www.paypal.com/en_AU/i/scr/pixel.gif" width="250" height="50" />
</form>
    </body></html>



