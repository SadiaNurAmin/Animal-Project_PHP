<html>
<head>
<style>
<?php 
include 'adminmain.css'; 
    ?>
</style>

</head><?php include "db.php"; ?>
<style>
table{
    width: 100%;
    border-collapse: collapse;
	border: 4px solid black;
    padding: 1px;
	font-size: 25px;
}

th{
border: 1px solid black;
	background-color: #4CAF50;
    color: white;
	text-align: left;
}
tr,td{
	border: 1px solid black;
	background-color: white;
    color: black;
}
</style>


	
	<form action="notify.php" method="post">
	<div>
		
				
				<table>
				<tr>
				<th>User ID</th>
				<th>Animal Type</th>
				
			<th>Animal Breed</th>
                
				
				</tr>
                    
                    
  <?php    
                             $q="select * from request ";
          $run_q=mysqli_query($con,$q);
      
      
        
        while($_row_products=mysqli_fetch_array($run_q)){
      
  
       
         
                    $u_id=$_row_products["u_id"];
			$type=$_row_products["type"];
			$breed=$_row_products["breed"];
          
		
		
                    
                    
            

       
			
				echo "<tr>";
					echo  '<td><input type="text" name="u_id"  value="'.$_row_products["u_id"].'" readonly></td>'
					.'<td><input type="text" name="type"  value="'.$_row_products["type"].'" readonly></td>'
					
					.'<td><input type="text" name="breed"  value="'.$_row_products["breed"].'"readonly></td>';
                  
				
			}
                   	
?>	
                     </table>
      
			
            
		
                
                    
                    
                    
			
			

			
            
		

	     
	</form>