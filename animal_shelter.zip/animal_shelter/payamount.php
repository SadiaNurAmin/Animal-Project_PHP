
<?php

session_start();


$con = mysqli_connect('localhost','root','');
mysqli_select_db($con,'animal__shelter');


$name = $_POST['name'];
$city = $_POST['city'];
$amount = $_POST['amount'];


$reg= " insert into donor(name,city,amount) values('$name','$city','$amount')" ;
 
 $_SESSION['name']=$name;
header('location:paid.php');



?>