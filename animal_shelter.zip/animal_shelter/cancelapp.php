<html>
<head>
    <style>
<?php 
include 'adminmain.css'; 
    ?>
</style>

<style>
table{
    width: 85%;
    border-collapse: collapse;
	border: 4px solid black;
    padding: 5px;
	font-size: 25px;
}

th{
border: 4px solid black;
	background-color: #4CAF50;
    color: white;
	text-align: left;
}
tr,td{
	border: 4px solid black;
	background-color: white;
    color: black;
}
</style>

</head><?php include "db.php"; ?>

<div class="header">
				<ul>
                    <li style="float:left;border-right:none;color:white;"><strong><h3><?php  session_start();  echo $_SESSION['user_id']; ?></h3></strong></li>
					
				</ul>
</div>
<center>
	<?php
    $user_id=$_SESSION['user_id'];
      $q="select * from appointment where user_id ='$user_id'";
          $run_q=mysqli_query($con,$q);
      
      
        
        while($_row_products=mysqli_fetch_array($run_q)){
      
  
       
         
                    $u_id=$_row_products["user_id"];
			$a_id=$_row_products["animal_id"];
			$tmstmp=$_row_products["timestamp"];
			$stts=$_row_products["status"];
		
                    
    
    
    
    
    
    
	
	$sql1 = "Select * from appointment where user_id ='$u_id'";
			$result1=mysqli_query($con, $sql1);  
			echo "<table>
					<tr>
					<th>Appointment-Date</th>
					<th>User ID</th>
					
					<th>Animal ID</th>
					<th>Status</th>
					
					</tr>";
			while($row1 = mysqli_fetch_array($result1))
			{
				
								echo "<tr>";
                
								echo "<td>" . $row1['timestamp'] . "</td>";
								echo "<td>" . $row1['user_id'] . "</td>";
								echo "<td>" . $row1['animal_id']. "</td>";
							
								echo "<td>" . $row1['status'] . "</td>";
								
								echo "</tr>";
						}
        }
				
				
			
	?>
</center>
</body>
</html>