<style>
<?php 
include 'style.css'; 
    ?>
</style>




<html>
<head>
    <title> User Login And Registration </title>
     <!-- <link rel="stylesheet"  type="text/css"  href="style.css" >-->
	   <link rel="stylesheet" type="text/css"  href=" https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	    
  
</head>
<body>

<div class="container"> 
  <!--<div class "login-box">-->
      <div class="row">
      <div class="col-md-6 login-left">
          <h2>  <font color="white"> Make Appointment</font> </h2>

          
<form  action ="appointment_tbl.php" method="post">

   
    <div class="form-group">
    <label> <font color="white">Time Slot </font></label>
<input type="date" name="time" class="form-control" required>
</div>
    
    
    
    
<div class="form-group">
 <label> <font color="white">Animal ID of the animal you want</font></label>
<input type="text" name="animal_id" class="form-control" required> 
</div>
    <div class="form-group">
    <label> <font color="white">User ID </font></label>
<input type="text" name="user_id" class="form-control" required>
</div>
    <button type="submit" class="btn btn-primary">Submit </button>