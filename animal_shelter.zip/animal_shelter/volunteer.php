<!DOCTYPE html>
<?php
include("db.php");
include("function/count.php");


 
?>
<style>
<?php 
include 'adminmain.css'; 
    ?>
</style>
<html>

  <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <title>Insert Article </title>
        
    </head>
    
    <body bgcolor="#a687e0">
        
        <form method="post" action="volunteer.php" enctype="multipart/form-data">
        <table width="700" align="center" border="2" bgcolor="#efbd7c" ]>
            
            <tr align="center">
            
            <td colspan="2"><h1>Submit Article</h1></td>
            
            
            </tr>
            <tr>
             <td align="right"><b>Volunteer ID</b></td>
            <td><input type="text" name="user_id" /></td>
            
            
            </tr>
            
          <tr>
             <td align="right"><b>Article</b></td>
            <td><input type="file" name="article" /></td>
            
            
            </tr>
            
        
            
        
            
        
             <tr align="center">
            
            <td colspan="2"><input type="submit" name="insert_data" value="Submit" /></td>
            
            
            </tr>
            
            
            
            </table>
        
        
        </form>
        
        <?php
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con,'animal__shelter');


if(isset($_POST['insert_data'])){
    $volunteer_id= $_POST['user_id'];
     $article = $_FILES['article']['name'];
    $temp_article = $_FILES['article']['name'];
    
     $s = "select * from usertable where user_id= '$volunteer_id'";
$result = mysqli_query($con, $s);
$num = mysqli_num_rows($result);
  
      
        
        $insert_data="insert into volunteer (volunteer_id,article) values ('$volunteer_id','$article')";
 
           
        
        mysqli_query($con,$insert_data);
            echo "<script>alert('Data inserted successfully')</script>";
        }
        ?>

  
    
    
  
    
    </body>
    

</html>

