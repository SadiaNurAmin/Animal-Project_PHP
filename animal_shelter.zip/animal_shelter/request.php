<style>
<?php 
include 'adminmain.css'; 
    ?>
</style>
<html>


<ul>

   <li>  
	<form method="post" action="login.php">	
	<button type="submit" class="cancelbtn" name="logout" style="float:right;font-size:22px"><b>Log Out</b></button>
	</form>
  </li>
	
</ul>

<h1>
<center><h1>REQUEST PET</h1><hr>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
 
Enter Animal Type:<center><input type="text" name="animal_type"></center>
Enter Animal Breed:<center><input type="text" name="animal_breed"></center>
Enter User ID:<center><input type="text" name="animal_b"></center>
   
    
    

			<button type="submit" name="Submit1">Request</button>
			

				
				
				
</form>			
<?php
session_start();
include 'db.php';
if(isset($_POST['Submit1']))
{
	$type=$_POST['animal_type'];
	$u_id=$_POST['animal_b'];
    $breed=$_POST['animal_breed'];
   
    $status=" Registered.Wait for the update";
	$sql =" insert into request(type,u_id,breed,status) values ('$type','$u_id' ,'$breed','$status')";
	
	if (mysqli_query($con, $sql))
		{
		echo "Request Submitted!";
	
		}
	
	
}

if(isset($_POST['logout'])){
		session_unset();
		session_destroy();
		header( "Refresh:1; url=login.php"); 
	}
?>			
</body>
</html>