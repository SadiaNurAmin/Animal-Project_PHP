<style>
<?php 
include 'stylehome.css'; 
    ?>
</style>




<section class="banner">
				<div class="wrapper">
					<div class="banner-content">
						<h3>The “Big Dogs” Need the Most Love and Walking.</h3>
						<p>When first starting out as a volunteer, shelters often restrict you from walking or fraternizing with bigger dogs because of obvious reasons, but as a result, these dogs do not get walked as much even though they are the ones that need it the most. I see them in their cages just longing to go on a walk, begging to be given just a small pat on the head or a belly rub while the Chihuahuas and dachshunds get all the attention. The small ones may be cute and portable, but the big ones still need love and never get enough of it.- Homaira Huda Shomee</p>
					<br>
				
						<h3>Cats Need Just as Much Love as Dogs.</h3>
						<p>When I first started volunteering at my local animal shelter, I was told that I should go through the cat handling training as soon as I could because no one seems to want to deal with cats. Now, this could be from cat allergies or some other innocuous reason, but I was shocked being the fervent cat lover that I am. I was in disbelief until I signed up for cat training, got my certificate, and went volunteering the next day: practically no one was in the cat “tent” helping them, petting them, or tending to them. Sure, the staff was there, but they have other duties on hand and do not have time to just give the cats love- Arpita Chaity</p>
				</div>
				</section>