<html>
<head>
<style>
<?php 
include 'adminmain.css'; 
    ?>
</style>

</head><?php include "db.php"; ?>
<style>
table{
    width: 100%;
    border-collapse: collapse;
	border: 4px solid black;
    padding: 1px;
	font-size: 25px;
}

th{
border: 1px solid black;
	background-color: #4CAF50;
    color: white;
	text-align: left;
}
tr,td{
	border: 1px solid black;
	background-color: white;
    color: black;
}
</style>
    
    <form action="list.php" method="post">
	<div>
        
	
				<table>
				<tr>
				<th>User Name</th>
				<th>User ID</th>
                    <th>Phone Number</th>
                    <th>Address</th>
                 
				</tr>
                    
                    
                      <?php    
                             $q="select * from usertable ";
          $run_q=mysqli_query($con,$q);
      
      
        
        while($rp=mysqli_fetch_array($run_q)){
      
  
       $name = $rp['name'];
$user_id = $rp['user_id'];

$phone_number = $rp['phone_number'];
$address = $rp['address'];

		
		
                    
                    
            

       
			
				echo "<tr>";
					echo  '<td><input type="text" name="u_id"  value="'.$rp["name"].'" readonly></td>'
					.'<td><input type="text" name="type"  value="'.$rp["user_id"].'" readonly></td>'
					
					
					.'<td><input type="text" name="breed"  value="'.$rp["phone_number"].'"readonly></td>'
                        .'<td><input type="text" name="type"  value="'.$rp["address"].'" readonly></td>';
                  
				
			}
                   	
?>	
                     </table>
      
			
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    