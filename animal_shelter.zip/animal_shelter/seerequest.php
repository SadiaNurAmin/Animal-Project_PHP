<html>
<head>
    <style>
<?php 
include 'adminmain.css'; 
    ?>
</style>

<style>
table{
    width: 85%;
    border-collapse: collapse;
	border: 4px solid black;
    padding: 5px;
	font-size: 25px;
}

th{
border: 4px solid black;
	background-color: #4CAF50;
    color: white;
	text-align: left;
}
tr,td{
	border: 4px solid black;
	background-color: white;
    color: black;
}
</style>

</head><?php include "db.php"; ?>

<div class="header">
				<ul>
                    <li style="float:left;border-right:none;color:white;"><strong><h3><?php  session_start();  echo $_SESSION['user_id']; ?></h3></strong></li>
					
				</ul>
</div>
<center>
	<?php
    $user_id=$_SESSION['user_id'];
      $q="select * from request where user_id ='$user_id'";
          $run_q=mysqli_query($con,$q);
      
      
        
        while($_row_products=mysqli_fetch_array($run_q)){
      
  
       
         
                    $u_id=$_row_products["u_id"];
			$type=$_row_products["type"];
			$breed=$_row_products["breed"];
			$stts=$_row_products["status"];
		
                    
    
    
    
    
    
    
	
	$sql1 = "Select * from request where user_id ='$u_id'";
			$result1=mysqli_query($con, $sql1);  
			echo "<table>
					<tr>
					<th>Animal Type</th>
                    <th>Animal Breed</th>
					<th>User ID</th>
					
					<th>Status</th>
					
					</tr>";
			while($row1 = mysqli_fetch_array($result1))
			{
				
								echo "<tr>";
                
								echo "<td>" . $row1['type'] . "</td>";
								echo "<td>" . $row1['breed'] . "</td>";
								echo "<td>" . $row1['u_id']. "</td>";
							
								echo "<td>" . $row1['status'] . "</td>";
								
								echo "</tr>";
						}
        }
				
				
			
	?>
</center>
</body>
</html>