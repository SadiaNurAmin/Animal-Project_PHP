<!DOCTYPE html>
<?php
include("db.php");
include("function/count.php");


 




      
        $get_article= "select * from volunteer";
      
        $run_art = mysqli_query($con, $get_article);
        
        while($row_products=mysqli_fetch_array($run_art)){
      
          
      
         
           
    $volunteer_id= $_POST['user_id'];
     $article = $_FILES['article']['name'];
    $temp_article = $_FILES['article']['name'];
   
           
            
        echo"<div id='single_pic'><h3>$volunteer_id</h3>
        
        <txt src='doggy/$article'   />
        
      <div id='space'>
  
      
       
         
       </div>
      
        
        </div>";}
?>