<?php

session_start();


$con = mysqli_connect('localhost','root','');
mysqli_select_db($con,'animal__shelter');

$name = $_POST['user'];
$user_id = $_POST['user_id'];
$pass = $_POST['password'];
$phone_number = $_POST['phone_number'];
$address = $_POST['address'];
$type= $_POST['usertype'];

$s = "select * from usertable where user_id = '$user_id'";
$result = mysqli_query($con, $s);
$num = mysqli_num_rows($result);

if($num == 1){
echo "User ID already taken";

}
else{
    $qry = mysqli_fetch_array($result);
        
        $_SESSION['user_id'] = $qry['user_id'];
        $_SESSION['usertype'] = $qry['usertype'];
 
  
    
    
      
        $reg= " insert into usertable(name,user_id,password,phone_number,address,usertype) values ('$name' ,'$user_id', '$pass','$phone_number','$address','$type')";
mysqli_query($con,$reg);
            header("location:login.php");
  
    
}

?>