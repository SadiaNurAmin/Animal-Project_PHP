<?php

session_start();
if(!isset($_SESSION['name'])){
  header('location:payamount.php');
}
?>

<html>
    <head>
        <title> PAID </title>
          <link rel="stylesheet"  type="text/css"  href="style.css" >
	   <link rel="stylesheet" type="text/css"  href=" https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	    
    </head>
    <body>
        
  
    <h1>Payment Successful <?php echo $_SESSION['name']; ?> </h1>
    
    </body>

    
    
</html>
