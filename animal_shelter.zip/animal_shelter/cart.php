<?php
include("db.php");
include("function/count.php");



?>

<style>
<?php 
include 'styledisplay.css'; 
    ?>
</style>

<html>
    <head>
    <title>List Of Animals</title>
       

    </head>
    
    <body>
        <section class="header">
            <div class="wrapper">
                <div class="menu">
                    <ul>
							<li><a href="homepage.php">Home</a></li>
							<li><a href="display.php">Go Back</a></li>
                    </ul>
                   
                   
            </div>
            </div>
        
        </section>
        
        <div id="headline">
        <div id="headline_content">
        <span><a href="cart.php">List Of animals chosen</a></span>
             <span> - Total Animals chosen:<?php amount();
                ?>  </span>
            </div>
            </div> 
        
         <div id="animal_box">
        <form action="cart.php" method="post" enctype="multipart/form-data" >
            
        <table width="700" align="center" bgcolor="#0099CC"><br>
            
            <tr align="center">
            <td><b>Remove</b></td>
            <td><b>Animal</b></td>
                
                <? php
    $ip_add=getRealIpAddr();
             
                $sel_price="select*from want_to_adopt where ip_ad='$ip_add'";
                $run_price=mysqli_query($con,$sel_price);
                
                
                while($record=mysqli_fetch_array($run_price)){
                $animal_id=$record['id'];
                $anim_id="select * from dogs  where id='$animal_id'";
                $run_ani = mysqli_query($con,$anim_id);
                
                 while($record=mysqli_fetch_array($run_ani)){
                 $animal= array($anm['id']);
                 $animal_name= $anm['name'];
                 $animal_name= $anm['image'];
                 
                 $value=array_sum($animal);
                
                
                
                }
                }               
                ?>
                
                
            
            
            </tr>
               </div> 
            
           
            
            
            
            
              
            
            
            
            
            
            <tr>
            <td><input type="checkbox" name="remove[]" value="<?php echo $animal_id;?>>" 
                </td>
               
            
            
            </tr>
            
            </table>
      
            
 
   
    
   
            
    
        
    <?php

        
      
         
        $get_products= "select * from dogs";
      
        $run_products = mysqli_query($con, $get_products);
        
        while($row_products=mysqli_fetch_array($run_products)){
      
            
           
    $animal_type = $row_products['animal_type'];
  $animal_name = $row_products['name'];
    $animal_gender = $row_products['gender'];
    $animal_breed = $row_products['breed'];
    $animal_id = $row_products['id'];
    $animal_age = $row_products['age'];
    $animal_detail = $row_products['detail'];
    $animal_image = $row_products['image'];
       
           
            
        
        }
            
            
            
            
        
        
        
        
     
        
        ?>
    
        
        
    
    
    </body>
    
</html>