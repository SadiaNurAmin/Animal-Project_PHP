<!DOCTYPE html>
		<html>
		<head>
			<meta charset="UTF-8">
			<title>Home page</title>
			<!--<link rel="stylesheet" href="stylehome.css">-->
            
            <style>
<?php 
include 'stylehome.css'; 
    ?>
</style>
		</head>
		<body>
		<!--menubar starts-->
		<div class="menubar">
			<div class="wrapper">
				<div class="logo">
					<img src="" alt="">
				</div>
				<div class="accounts">
					<ul>
						<li><a href="login.php">Log In</a></li>
						<li><a href="login.php">Register</a></li>
					</ul>
				</div>
			</div>
		</div>
		<!--menubar ends-->
		<!--header starts-->
			<section class="header">
				<div class="wrapper">
					<div class="menu">
						<ul>
							<li><a href="homepage.php">Home</a></li>
							<li><a href="display2.php">Gallery</a></li>
							
							<li><a href="article.php">Articles</a></li>
						</ul>
					</div>
					<div class="buttons">
						<button class="button1"><a href="login.php">Adopt</a></button>
		<button class="button2"><a href="payment_options.php">Donate</a></button>
		<button class="button3"><a href='login.php'>Volunteer</a/></button>
					</div>
					
				</div>
			</section>
		<!--header ends-->
		<!--banner starts-->
			<section class="banner">
				<div class="wrapper">
					<div class="banner-content">
						<h1>Open your Heart And Your Home</h1>
						<p>To adopt a pet is not an easy decision. Many people are afraid to adopt a pet because they do not want to take care of them. In our opinion, it looks like a kind of egoism from their side because every animal in a shelter is waiting for love and care from human side. There exist many shelters where different kinds of animals live and wait for their future owners. Thus, any person can make the life of these animals better by showing mercy to these homeless animals through their adoption.</p>
						
					</div>
				</div>
				</section>
		<!--banner ends-->
		<!--service starts-->
			<section class="service">
				<div class="wrapper">
					<div class="service-content">
						<h4>We Provide best Services</h4>
						<p>Know More About Us</p>
					</div>
				</div>
				</section>
		<!--service ends-->
		<!--FAQ starts-->
		<section class="faq">
			<div class="wrapper">
				<div class="topper">
					<h2>Join Our Family</h2>
				</div>
				<div class="single ">
					<p><a href="#">FAQs</a></p>
					<p><a href="#">Partnerships</a></p>
					<p><a href="#">Terms of Services</a></p>
					<p><a href="#">Mobile Site and App</a></p>
				</div>
				<!--2nd single-->
				<div class="single p">
					<p><a href="#">Our Foundation</a></p>
					<p><a href="#">Free Widgets and Graphics</a></p>
					<p><a href="#">Press</a></p>
					<p><a href="#">For developers</a></p>
				</div>
				<!--3rd single-->
				<div class="single p a">
					<p><a href="#">Contact Us</a></p>
					<p><a href="#">About our Ads</a></p>
					<p><a href="#">Privacy policy</a></p>
					<p><a href="#">Helping Pets</a></p>
				</div>
			</div>
		</section>
		<!--FAQ ends-->
		</body>
		</html>