<html>
<head>
<style>
<?php 
include 'adminmain.css'; 
    ?>
</style>

</head><?php include "db.php"; ?>
<style>
table{
    width: 100%;
    border-collapse: collapse;
	border: 4px solid black;
    padding: 1px;
	font-size: 25px;
}

th{
border: 1px solid black;
	background-color: #4CAF50;
    color: white;
	text-align: left;
}
tr,td{
	border: 1px solid black;
	background-color: white;
    color: black;
}
</style>


	
	<form action="approve.php" method="post">
	<div>
		
				
				<table>
				<tr>
				<th>User ID</th>
				<th>Animal ID</th>
				
			<th>Date and Time</th>
				<th>Status</th>
				</tr>
                    
                    
  <?php    
                             $q="select * from appointment ";
          $run_q=mysqli_query($con,$q);
      
      
        
        while($_row_products=mysqli_fetch_array($run_q)){
      
  
       
         
                    $u_id=$_row_products["user_id"];
			$a_id=$_row_products["animal_id"];
			$tmstmp=$_row_products["timestamp"];
			$stts=$_row_products["status"];
		
                    
                    
            

       
			
				echo "<tr>";
					echo  '<td><input type="text" name="user_id"  value="'.$_row_products["user_id"].'" readonly></td>'
					.'<td><input type="text" name="animal_id"  value="'.$_row_products["animal_id"].'" readonly></td>'
					
					.'<td><input type="text" name="timestamp" id="timestamp" value="'.$_row_products["timestamp"].'"readonly></td>'
					
            .'<td><input type="text" name="status" id="status" value="'.$_row_products["status"].'"></td></tr>' ;
			}
?>		
			</table>	
			<button type="submit" style="position:center" name="submit2" value="Submit">Submit Approval</button></form>		
<?php


			if(isset($_POST['submit2']))
		{
			$u_id=$_POST["user_id"];
			$a_id=$_POST["animal_id"];
			$tmstmp=$_POST["timestamp"];
			$stts=$_POST["status"];
			
             
           
			
		   

				$updatequery="update appointment set status='$stts' where user_id='$u_id' and timestamp='$tmstmp'";
				if (mysqli_query($con, $updatequery)) 
				{
							echo "Status updated successfully..!!<br>";

				} 
				else
				{
					echo "Error: " . $sql . "<br>" . mysqli_error($con);
				}
			}
			
            
		
?>
	     
	</form>