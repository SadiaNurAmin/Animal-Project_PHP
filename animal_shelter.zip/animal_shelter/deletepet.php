<style>
<?php 
include 'adminmain.css'; 
    ?>
</style>
<html>


<ul>

   <li>  
	<form method="post" action="admin.php">	
	<button type="submit" class="cancelbtn" name="logout" style="float:right;font-size:22px"><b>Go Back</b></button>
	</form>
  </li>
	
</ul>

<h1>
<center><h1>DELETE PET</h1><hr>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
Enter Animal Id:<center><input type="number" name="animal_id"></center>
			<button type="submit" name="Submit1">Delete</button>
			

				
				
				
</form>			
<?php
session_start();
include 'db.php';
if(isset($_POST['Submit1']))
{
	$id=$_POST['animal_id'];
	$sql = "DELETE FROM dogs WHERE id= $id ";
	
	if (mysqli_query($con, $sql))
		{
		echo "Record deleted successfully from animals table.Refreshing....";
		header( "Refresh:3; url=deletepet.php");
		}
	else
		{
			echo "Error deleting record: " . mysqli_error($con);
		}
		
	
}

if(isset($_POST['logout'])){
		session_unset();
		session_destroy();
		header( "Refresh:1; url=alogin.php"); 
	}
?>			
</body>
</html>