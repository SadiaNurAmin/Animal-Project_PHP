<style>
<?php 
include 'style.css'; 
    ?>
</style>




<html>
<head>
    <title> User Login And Registration </title>
     <!-- <link rel="stylesheet"  type="text/css"  href="style.css" >-->
	   <link rel="stylesheet" type="text/css"  href=" https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	    
  
</head>
<body>

<div class="container"> 
  <!--<div class "login-box">-->
      <div class="row">
      <div class="col-md-6 login-left">
          <h2>  <font color="white"> Login Here </font> </h2>

          
<form  action ="validation.php" method="post">
<div class="form-group">
   
    <div class="form-group">
    <label> <font color="white">User ID </font></label>
<input type="text" name="user_id" class="form-control" required>
</div>
<div class="form-group">
 <label> <font color="white">Password </font></label>
<input type="password" name="password" class="form-control" required> 
</div>
    
    <div class="form-group">
 <label><font color="white">User Type </font></label><select name="usertype">
        <option name="admin">Admin</option>
<option name="Client">Client</option>
<option name="Volunteer">Volunteer</option></select> 
</div>
    
    
<button type="submit" class="btn btn-primary"> Login </button>

    </form>
          
          
          </div>
    </div>

    
                    
          

          

  <div class="col-md-6 login-right">
      <h2>  <font color="white"> Register Here </font> </h2>

<form  action ="registration.php" method="post">
<div class="form-group">
 <label> <font color="white">Username </font></label>
<input type="text" name="user" class="form-control" required>
</div>
    <div class="form-group">
    <label> <font color="white">User_ID </font></label>
<input type="text" name="user_id" class="form-control" required>
</div>
<div class="form-group">
 <label> <font color="white">Password </font></label>
<input type="password" name="password" class="form-control" required> 
</div>
    
    <div class="form-group">
 <label><font color="white">User Type </font></label><select name="usertype">
      
<option name="client">Client</option>
<option name="volunteer">Volunteer</option></select> 
</div>
    
    <div class="form-group">
 <label> <font color="white">Phone Number </font></label>
<input type="int" name="phone_number" class="form-control" required> 
</div>
   <div class="form-group">
 <label> <font color="white">Address </font></label>
<input type="text" name="address" class="form-control" required> 
</div>
<button type="submit" class="btn btn-primary"> Register</button>
</form>
</div>

    </div>
    </div>
  
    </body>
</html>

    