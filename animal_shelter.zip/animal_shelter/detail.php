<!DOCTYPE html>
<?php
include("db.php");
include("function/count.php");
?>


<html>
    <head>
    <title>Gallery</title>
        
    </head>
    <style>
<?php 
include 'styledetail.css'; 
    ?>
</style>
<body>
 
    
   
   
            
    
     <div id="images_box">
        
    <?php

        if(isset($_GET['pet_id'])){
            
            $anim_id = $_GET['pet_id'];
      
         
        $get_products= "select * from dogs where id=$anim_id";
            
      
        $run_products = mysqli_query($con, $get_products);
        
        while($row_products=mysqli_fetch_array($run_products)){
      
            
           
    $animal_type = $row_products['animal_type'];
  $animal_name = $row_products['name'];
    $animal_gender = $row_products['gender'];
    $animal_breed = $row_products['breed'];
    $animal_id = $row_products['id'];
    $animal_age = $row_products['age'];
    $animal_detail = $row_products['detail'];
    $animal_image = $row_products['image'];
       
            
        echo"<div id='single_pic'><h3>$animal_name</h3>
        
        <img src='doggy/$animal_image' width='150' height='400' >
          <p> Animal ID: $animal_id </></p>
        <p> Breed: $animal_breed </></p>
         <p> Gender: $animal_gender</p>
        <p> Character: $animal_detail</p>
        <p> Age: $animal_age</p>
        
        
        </div>
        </div>";
        
        
        
      
       

       
        }}
            
            
            
            
        
        
        
        
     
        
        ?>
    
    </div>
    
    
    
    
    </body>
</html>







            