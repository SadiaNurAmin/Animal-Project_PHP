<!DOCTYPE html>
<?php
include("db.php");



 
?>

<style>
<?php 
include 'styledisplay.css'; 
    ?>
</style>

<html>
    <head>
    <title>Gallery</title>
        
    </head>
<body>
    
   
    
     <div id="form">
        <form method="get" action="result.php" enctype="multipart/form-data" >
        
      
            <select name="user_search" class="form-control">
            <option value="">Search Animal</option>
                <option value="Dog">Dog</option>
             <option value="Cat">Cat</option>
                 <option value="Others">Others</option>
            </select>
            <input type="submit" name="search" value="GO!" />
        </form>
    
    </div>
   
            
    
     <div id="images_box">
        
    <?php

      if(isset($_GET['search'])) { 
          
          $user_search=$_GET['user_search'];
      
         
        $get_pet= "select * from dogs where animal_type='$user_search'";
      
        $run_search = mysqli_query($con, $get_pet);
        
        while($row_products=mysqli_fetch_array($run_search)){
      
            
           
    $animal_type = $row_products['animal_type'];
  $animal_name = $row_products['name'];
    $animal_gender = $row_products['gender'];
    $animal_breed = $row_products['breed'];
    $animal_id = $row_products['id'];
    $animal_age = $row_products['age'];
    $animal_detail = $row_products['detail'];
    $animal_image = $row_products['image'];
             $animal_type = $row_products['animal_type' ];
       
           
            
        echo"<div id='single_pic'><div id='wrapper'><h3>$animal_name</h3>
        
        <img src='doggy/$animal_image' width='180' height='180'  /><br>
        
        <p><b> Breed: $animal_breed </b></>
        
        <a href= 'detail.php?pet_id=$animal_id' style='float:left;'>DETAILS</a>
       
        <button><a href='appointment_tbl.php?like=$animal_id'>REQUEST</a></button>
        
        </div>
        </div>";
        }
            
            
            
      }
        
        
        
        
     
        
        ?>
    
    </div>
    
    
    
    
    </body>
</html>
            