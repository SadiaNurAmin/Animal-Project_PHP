<!DOCTYPE html>
<?php
include("db.php");
include("function/count.php");


 
?>


<style>
<?php 
include 'styledisplay.css'; 
    ?>
</style>
<ul>

   <li>  
	<form method="post" action="login.php">	
	<button type="submit" class="cancelbtn" name="appointment" style="float:right;font-size:22px;color: #1f1f1f;"><b>Book</b></button>
	</form>
  </li>
	
</ul>



<html>
    <head>
    <title>Gallery</title>
       

    </head>
<body>
   
                    
   <div id="header">
        <form method="get" action="result.php" enctype="multipart/form-data" >
            
        
      
            <select name="user_search" class="form-control" >
            <option value="">Search Animal</option>
                <option value="Dog">Dog</option>
             <option value="Cat">Cat</option>
                 <option value="Other">Others</option>
            </select>
            <input type="submit" name="search" value="GO!"  />
        </form>
    
    </div>
    
    
  
       
    
        <?php
     
  
    
        
      
         
        $get_products= "select * from dogs";
      
        $run_products = mysqli_query($con, $get_products);
        
        while($row_products=mysqli_fetch_array($run_products)){
      
            
           
    $animal_type = $row_products['animal_type'];
  $animal_name = $row_products['name'];
    $animal_gender = $row_products['gender'];
    $animal_breed = $row_products['breed'];
    $animal_id = $row_products['id'];
    $animal_age = $row_products['age'];
    $animal_detail = $row_products['detail'];
    $animal_image = $row_products['image'];
       
           
            
        echo"<div id='single_pic'><div id='wrapper'><h3>$animal_name</h3>
        
        <img src='doggy/$animal_image' width='180' height='180'  />
        
      <div id='space'>
        
       <button> <a href= 'detail.php?pet_id=$animal_id' style='float:left;'>DETAILS</a></button>
      
       
         
       </div>
      
        
        </div>";
        }
            
            
            
            
        
        
        
        
     
        
        ?>
    
    
   
    
   
    
   
            
    
        

    
    
    
    
    
    
    </body>
</html>
            