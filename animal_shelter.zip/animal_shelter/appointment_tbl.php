  <style>
<?php 
include 'main.css'; 
    ?>
</style>


<html>
    <ul>

   <li>  
	<form method="post" action="login.php">	
	<button type="submit" class="cancelbtn" name="logout" style="float:right;font-size:22px"><b>Log Out</b></button>
	</form>
  </li>
	
</ul>

  
    <?php include "db.php"; ?>

<body style="background-image:url(doggy/wow.jpg)">

	<form action="appointment_tbl.php" method="post">
	<div class="sucontainer" >
        
		
		
		
	
		<label style="font-size:20px" >User ID</label><br>
		<input type="text"  name="u_id"  style="width:100%;height:35px;border-radius:9px">
		
		<br>
		
            <label style="font-size:20px" >Animal ID</label><br>
		<input type="number" name="a_id" style="width:100%;height:35px;border-radius:9px">
       
        <br>
		
		
		
		<label><b>Date of Visit:</b></label><br>
		<input type="date" name="dov" >
            <br><br>
		<div id="datestatus"> </div>
		<div class="container">
			<button type="submit" style="position:center" name="submit" value="Submit">Submit</button>
		</div>
        </div
       
<?php

if(isset($_POST['submit']))
{
	
		
		$animal_id=$_POST['a_id'];
		$user_id=$_POST['u_id'];
		
		$dov=$_POST['dov'];
		$status="Booking Registered.Wait for the update";
		$timestamp=date('Y-m-d H:i:s');
		$sql = "INSERT INTO appointment (user_id,animal_id,Date,status) VALUES ('$user_id','$animal_id','$dov','$status') ";

		
				if (mysqli_query($con, $sql)) 
				{
						echo "<h2>Booking successful!! Redirecting to home page....</h2>";
						header( "display.php");

				} 
				else
				{
					echo "Error: " . $sql . "<br>" . mysqli_error($con);
				}
			}
		
?>
        
	</form>
</body>
</html>
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
	</form>
</body>
</html>