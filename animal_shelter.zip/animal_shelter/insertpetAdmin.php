
<!DOCTYPE HTML>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <title>Insert Data </title>
        <style>
<?php 
include 'adminmain.css'; 
    ?>
</style>
    </head>
    
    <body bgcolor="#cceb99">
        
        <form method="post" action="insertpetAdmin.php" enctype="multipart/form-data">
        <table width="700" align="center" border="2" bgcolor="#f4bc7a">
            
            <tr align="center">
            
            <td colspan="2"><h1>Insert Animal Details </h1></td>
            
            
            </tr>
            <tr>
            <td align="right"><b>Name</b></td>
            <td><input type="text" name="animal_name" /></td>
            
            
            </tr>
            
         
            <tr>
                <td align="right" ><b>Gender</b></td>
		<td><input type="radio" name="animal_gender" value="female">Female
		<input type="radio" name="animal_gender" value="male">Male
		<input type="radio" name="animal_gender" value="other">Other<br><br></td>
            </tr>
            
             <tr>
             <td align="right"><b>Breed</b></td>
            <td><input type="text" name="animal_breed" /></td>
            
            
            </tr>
            
          <tr>
                <td align="right"><b>Type</b></td>
		<td><input type="radio" name="animal_type" value="Dog">Dog
		<input type="radio" name="animal_type" value="Cat">Cat
		<input type="radio" name="animal_type" value="other">Other<br><br></td>
            </tr>
            
             <tr>
             <td align="right"><b>ID</b></td>
            <td><input type="text" name="animal_id" /></td>
            
            
            </tr>
            
             <tr>
             <td align="right"><b>Age</b></td>
            <td><input type="text" name="animal_age" /></td>
            
            
            </tr>
            
             <tr>
             <td align="right"><b>Details About the Animal</b></td>
            <td><textarea name="animal_detail" cols="35" rows="10"></textarea></td>
            
            
            </tr>
            
             <tr>
             <td align="right"><b>Animal Picture</b></td>
            <td><input type="file" name="animal_image" /></td>
            
            
            </tr>
            
        
             <tr align="center">
            
            <td colspan="2"><input type="submit" name="insert_data" value="Submit" /></td>
            
            
            </tr>
            
            
            
            </table>
        
        
        </form>
  
    
    </body>
    

</html>
<?php
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con,'animal__shelter');


if(isset($_POST['insert_data'])){
   
    $animal_name = $_POST['animal_name'];
    $animal_gender = $_POST['animal_gender'];
    $animal_breed = $_POST['animal_breed'];
    $animal_type = $_POST['animal_type' ];
    $animal_id = $_POST['animal_id'];
    $animal_age = $_POST['animal_age'];
    $animal_detail = $_POST['animal_detail'];
    $animal_image = $_FILES['animal_image']['name'];
    $temp_animal_image = $_FILES['animal_image']['name'];
  
 
    
         $s = "select * from dogs where id= '$animal_id'";
$result = mysqli_query($con, $s);
$num = mysqli_num_rows($result);

if($num == 1){
echo "Animal already registered";
}
        else{

        
        move_uploaded_file($temp_animal_image,"doggy_pic/$animal_image");
        
        $insert_data="insert into dogs (animal_type,name,gender,breed,id,age,detail,image) values ('$animal_type','$animal_name','$animal_gender','$animal_breed','$animal_id','$animal_age','$animal_detail','$animal_image')";
 
           
        
        mysqli_query($con,$insert_data);
            echo "<script>alert('Data inserted successfully')</script>";
        }

  
    
    }



























?>