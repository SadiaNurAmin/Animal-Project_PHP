<?php

session_start();


$con = mysqli_connect('localhost','root','');
mysqli_select_db($con,'animal__shelter');


$user_id = $_POST['user_id'];
$pass = $_POST['password'];
$type= $_POST['usertype'];

		

	$s = "select * from usertable where user_id='$user_id' AND usertype='$type'";
$result = mysqli_query($con, $s);
$num = mysqli_num_rows($result);

if($num == 1){
     
$qry = mysqli_fetch_array($result);
        
        $_SESSION['user_id'] = $qry['user_id'];
        $_SESSION['usertype'] = $qry['usertype'];
        if($qry['usertype']=="admin"){
            header("location:admin.php");
        }
    else if($qry['usertype']=="Client"){
            header("location:loginpage.php");
        }
    else if($qry['usertype']=="Volunteer"){
            header("location:volunteer.php");
        }
}





























?>