<style>
<?php 
include 'adminmain.css'; 
    ?>
</style>

<ul>

   <li>  
	<form method="post" action="login.php">	
	<button type="submit" class="cancelbtn" name="logout" style="float:right;font-size:22px"><b>Log Out</b></button>
	</form>
  </li>
	
</ul>

<div class="buttons">
    
		<center><button class="button3"><a href="insertpetAdmin.php"><h3>Add Pets</h3></a></button>
    <button class="button2"><a href="deletepet.php"><h3>Delete Pet </h3></a></button>
		<button class="button3"><a href='approve.php'><h3>Approve Appointment</h3></a></button>
		<button class="button3"><a href='notify.php'><h3>Check Request</h3></a></button>
		<button class="button3"><a href='list.php'><h3>List of all users</h3></a></button>
        
					</div> </center>
 <body>
        
        <div class="container"></div>
        
       
        
    
    
    
    </body>