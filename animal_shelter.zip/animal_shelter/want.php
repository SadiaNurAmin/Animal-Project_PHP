<!DOCTYPE html>
<?php
include("db.php");
include("function/count.php");
?>
<style>
<?php 
include 'styledisplay.css'; 
    ?>
</style>

<html>
    <head>
    <title>Gallery</title>
       

    </head>
<body>
    
   
    
     <div id="images_box">

         
       
    <?php

      if(isset($_GET['like'])) { 
          
          $animal_wanted=$_GET['like'];
      $checkif="select * from dogs where id=$animal_wanted ";
            //$quantity=$_GET['quantity'];
       //++$quantity;
          
      
      
        $run_checkif = mysqli_query($con, $checkif);
          $num = mysqli_num_rows( $run_checkif);
        
        
         
        
              $q="insert into want_to_adopt (animal_id) values ('$animal_wanted')";
          $run_q=mysqli_query($con,$q);

         
        while($row_products=mysqli_fetch_array($run_checkif)){
      
     
           
    $animal_type = $row_products['animal_type'];
  $animal_name = $row_products['name'];
    $animal_gender = $row_products['gender'];
    $animal_breed = $row_products['breed'];
    $animal_id = $row_products['id'];
    $animal_age = $row_products['age'];
    $animal_detail = $row_products['detail'];
    $animal_image = $row_products['image'];
          
       
           
            
        echo"<div id='single_pic'><h3>$animal_name</h3>
        
        <img src='doggy/$animal_image' width='180' height='180'  /><br>
        
        <p><b> Breed: $animal_breed </b></>
        
        <a href= 'detail.php?pet_id=$animal_id' style='float:left;'>DETAILS</a>
       
       <a href='want.php?like=$animal_id'><button style='float:none;'>Like It</a>
        
        </div>";
        }
            
            
            
      }
          
          
             
        
        
        
        
     
        
        ?>
    
    </div>
    
    
    
    
    </body>
</html>
            